#define UTS_RELEASE "5.10.0-kamakiri-amd64"
