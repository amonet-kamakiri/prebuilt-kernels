#define UTS_RELEASE "4.19.0-kamakiri-amd64"
